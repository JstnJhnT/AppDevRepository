public interface Payment {
    public void pay(double amount);
}
