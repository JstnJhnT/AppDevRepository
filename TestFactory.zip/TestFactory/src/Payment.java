public interface Payment {

}
